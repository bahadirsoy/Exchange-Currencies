//Get elements
const currencyFromElement=document.getElementById("currencyFromElement");
const toElement=document.getElementById("toElement");
const currencyToElement=document.getElementById("currencyToElement");
const exchangedInput=document.getElementById("exchangedInput");

class UI{
    constructor(currencyFrom,currencyTo){
        this.currencyFrom=currencyFrom;
        this.currencyTo=currencyTo;
    }

    changeCurrencyFrom(currencyFrom){
        currencyFromElement.textContent=currencyFrom;
        this.currencyFrom=currencyFrom;
    }

    changeCurrencyTo(currencyTo){
        currencyToElement.textContent=currencyTo;
        this.currencyTo=currencyTo;
    }

    changeExchangedInput(amount){
        exchangedInput.value=amount;
    }
}
