//Get elements
const currencyFromInput=document.getElementById("currencyFromInput");
const currencyToInput=document.getElementById("currencyToInput");
const amountElement=document.getElementById("amountElement");


//Inıt listeners
setEvenetListeners();

//Create an UI object
const ui=new UI(null,null);

//Create an Exchange object
const exchange=new Exchange(null,null);


//Create event listeners
function setEvenetListeners(){
    currencyFromInput.onchange=function(){
        currencyFromElement.textContent=currencyFromInput.options[currencyFromInput.selectedIndex].textContent;
        exchange.currencyFrom=currencyFromInput.options[currencyFromInput.selectedIndex].textContent;
        exchangeAmount();
    }

    currencyToInput.onchange=function(){
        currencyToElement.textContent=currencyToInput.options[currencyToInput.selectedIndex].textContent;
        exchange.currencyTo=currencyToInput.options[currencyToInput.selectedIndex].textContent;
        exchangeAmount();
    }

    amountElement.addEventListener("input",exchangeAmount);
}

//Exchange
function exchangeAmount(){
    fetch(exchange.link+exchange.currencyFrom)
    .then(response => response.json())
    .then(data => {
        exchange.amount=amountElement.value;
        const parity=data.rates[exchange.currencyTo];
        ui.changeExchangedInput(exchange.amount*parity);
    })
    .catch(err => console.log(err));
}