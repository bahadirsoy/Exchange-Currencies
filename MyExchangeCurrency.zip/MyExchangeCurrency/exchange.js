class Exchange{
    constructor(currencyFrom,currencyTo){
        this.currencyFrom=currencyFrom;
        this.currencyTo=currencyTo;
        this.link="https://api.exchangeratesapi.io/latest?base=";
        this.amount=null;
    }

    
}